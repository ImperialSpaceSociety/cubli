function set_input(pos)

    global cubli
        
    % system control input
    if cubli.input_flag == 1
        cubli.params.u = cubli.params.U(pos);
    else
        cubli.params.u = 0;
    end
    
end