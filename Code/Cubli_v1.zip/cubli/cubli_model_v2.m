%% Cubli model:
% x(1) = face angular position
% x(2) = flywheel angular position
% x(3) = face angular velocity
% x(4) = flywheel angular velocity
function x_dot = cubli_model_v2(t,x)

    global cubli
    x_dot = zeros(length(x),1);
    hit_angle = 0;
    
    rebounce_factor = 1;
    bounce_scale_vel = rebounce_factor;
    bounce_scale_acc = rebounce_factor;
    
    % check floor hit
    if x(1) <= hit_angle || x(1) >= (pi - hit_angle)
        x_dot(1) =  -bounce_scale_vel*x(1)/cubli.simulation.Ts;
        x_dot(2) = x(4);
        
        x_dot(3) = -bounce_scale_acc*x(3)/cubli.simulation.Ts;
        x_dot(4) = (cubli.params.u*(cubli.params.If + cubli.params.Iw) - cubli.params.Fw*x(4)*(cubli.params.If + cubli.params.Iw) - cubli.params.Lt*cubli.params.M*cubli.params.g*sin(x(1))*cubli.params.Iw...
                    + cubli.params.Fc*x(3)*cubli.params.Iw)/(cubli.params.If*cubli.params.Iw);
    else
        % dynamic equations
        x_dot(1) = x(3);
        x_dot(2) = x(4);

        x_dot(3) = (cubli.params.Lt*cubli.params.M*cubli.params.g*sin(x(1)) - cubli.params.u + cubli.params.Fw*x(4) - cubli.params.Fc*x(3))/cubli.params.If;
        x_dot(4) = (cubli.params.u*(cubli.params.If + cubli.params.Iw) - cubli.params.Fw*x(4)*(cubli.params.If + cubli.params.Iw) - cubli.params.Lt*cubli.params.M*cubli.params.g*sin(x(1))*cubli.params.Iw...
                    + cubli.params.Fc*x(3)*cubli.params.Iw)/(cubli.params.If*cubli.params.Iw);    
    end
    
end