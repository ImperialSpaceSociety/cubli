%% PLANT model and data
% model simulation
% plant data

global cubli

% phisycal parameters
cubli.params.Lt = 1;
cubli.params.COM = cubli.params.Lt*sqrt(2);
cubli.params.M = 1;
cubli.params.g = -9.81;
cubli.params.Fw = 0.5;
cubli.params.Fc = 0.5;
cubli.params.If = 5;
cubli.params.Iw = 3;
cubli.params.Km = 1;

% simulation
cubli.simulation.Tstart = 0;
cubli.simulation.Tend = 10;
cubli.simulation.Ts = 1e-2;
cubli.simulation.time = cubli.simulation.Tstart:cubli.simulation.Ts:cubli.simulation.Tend;
cubli.simulation.Niter = length(cubli.simulation.time);
cubli.simulation.model = @cubli_model_v2;

% init and other conditions/parameters
cubli.StateDim = 4;
cubli.init_condition = [pi/2; 0; 1e-3; 0];

% input signal
cubli.input_flag = 0;

% sinusoid
cubli.params.Tm = cubli.params.Km*sin(20*cubli.simulation.time);
% step
init_step = 10;
cubli.params.Tm = -1e0*cubli.params.Km*[zeros(1,init_step), ones(1,cubli.simulation.Niter-init_step)];

% input
cubli.params.U = cubli.params.Tm;