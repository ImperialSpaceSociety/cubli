%% plot section 

global cubli

%% plant test
if 1
    figure(1)
    for i=1:cubli.StateDim
        ax(i)=subplot(cubli.StateDim,1,i);
        plot(cubli.simulation.time,cubli.stateStory(i,:),'LineWidth',2);
        grid on
        ylabel(strcat('x_',int2str(i)));
        title('Simulation test ')
        legend(strcat('x_',int2str(i)))
    end
end

figure
plot(cubli.coordinates(:,1),cubli.coordinates(:,2),'bo');
xlim([-1.5 1.5])
ylim([-1.5 1.5])

